#include "akai_bridge.h"
#include "akaiutil_api.h"     // provides akai_read_sample_from_file
#include "akai_export.h"      // provides akai_export_sample
#include <string.h>
#include <stdio.h>

bool akai_convert_file(const char *inputPath, const char *outputDir, const char *modelName, bool normalize, bool trim) {
    AkaiModel model = AKAI_MODEL_S1000; // default fallback

    if (strcmp(modelName, "S950") == 0) model = AKAI_MODEL_S950;
    if (strcmp(modelName, "S1000") == 0) model = AKAI_MODEL_S1000;
    if (strcmp(modelName, "S1100") == 0) model = AKAI_MODEL_S1100;
    if (strcmp(modelName, "S3000") == 0) model = AKAI_MODEL_S3000;

    AkaiExportOptions options = {
        .normalize = normalize,
        .trim_silence = trim,
        .pad_silence = false
    };

    sample_t *sample = akai_read_sample_from_file(inputPath);
    if (!sample) {
        printf("❌ Failed to read sample: %s\n", inputPath);
        return false;
    }

    process_samples_with_options(sample, &options);
    adjust_to_akai_compatibility(sample, model);

    bool success = akai_export_sample(sample, outputDir, model);
    free_sample(sample);

    return success;
}
