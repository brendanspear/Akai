#ifndef AKAI_CONSTANTS_H
#define AKAI_CONSTANTS_H

#define AKAI_NAME_LEN 32  // Define the required name length macro

#endif /* AKAI_CONSTANTS_H */
