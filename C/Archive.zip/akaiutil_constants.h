#ifndef AKAIUTIL_CONSTANTS_H
#define AKAIUTIL_CONSTANTS_H

#define AKAI_NAME_LEN 12  // Adjust value if needed

#endif /* AKAIUTIL_CONSTANTS_H */
