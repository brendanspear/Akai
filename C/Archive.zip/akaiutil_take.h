#ifndef AKAIUTIL_TAKE_H
#define AKAIUTIL_TAKE_H

#include "sample.h"

void akai_take_process(sample_t *sample);

#endif // AKAIUTIL_TAKE_H
