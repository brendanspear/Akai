// SampleProcessingTask.swift
// AkaiSConvert
// Copyright © 2024 Brendan Spear. All rights reserved.

import Foundation

struct SampleProcessingTask {
    let sampler: SamplerType
    let data: Data
}