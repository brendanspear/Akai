//  ConversionSettings.swift
//  AkaiSConvert

import Foundation

struct ConversionSettings {
    var sampler: SamplerType
    var trimSilence: Bool
    var addSilence: Bool
    var silenceDuration: Int
    var normalizeVolume: Bool
    var convertToMono: Bool
    var sampleRate: Int
    var bitDepth: Int
    var format: SampleFormat
    var outputFolderURL: URL?
}
