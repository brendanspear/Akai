//  FileStatus.swift
//  AkaiSConvert

import Foundation

enum FileStatus {
    case queued
    case converting
    case success
    case failed
}
