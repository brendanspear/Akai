//  AkaiSConvertApp.swift
//  AkaiSConvert
//
//  Created by Brendan Spear on 2025-05-15.
//

import SwiftUI
//import ContentView

@main
struct AkaiSConvertApp: App {
    @StateObject private var viewModel = ConversionViewModel()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
        .commands {
            AppMenuCommands(viewModel: viewModel)
        }
    }
}
