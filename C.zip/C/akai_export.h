//  akai_export.h
//  AkaiSConvert
//
//  Created by Brendan Spear on 2025-05-21.
//

#ifndef AKAI_EXPORT_H
#define AKAI_EXPORT_H

#include <stdbool.h>
#include "sample.h"
#include "akai_model.h"  // Defines AkaiModel enum (S900, S1000, S3000)

// Options for conversion to Akai format
typedef struct {
    bool normalize;
    bool trim_silence;
    bool pad_silence;
    int silence_ms;     // Amount of silence to pad (if pad_silence is true)
    bool force_mono;
} AkaiExportOptions;

#ifdef __cplusplus
extern "C" {
#endif

// Export function entry point
bool export_sample_to_akai_format(const char* input_path,
                                  const char* output_path,
                                  const AkaiExportOptions* options,
                                  AkaiModel model);

#ifdef __cplusplus
}
#endif

#endif /* AKAI_EXPORT_H */
