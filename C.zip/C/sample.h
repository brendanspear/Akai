#ifndef SAMPLE_H
#define SAMPLE_H

#include "akaiutil_constants.h"  // Ensure this has AKAI_NAME_LEN

typedef struct sample_s {
    char name[AKAI_NAME_LEN];
    unsigned int sample_rate;
    unsigned int length;
    unsigned char bit_depth;
    unsigned char channels;
    unsigned char *data;
} sample_t;

#endif /* SAMPLE_H */
