#ifndef AKAIUTIL_AUDIOUTILS_H
#define AKAIUTIL_AUDIOUTILS_H

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include "sample.h"
#include "akai_model.h"

// Internal normalization logic
bool normalize_pcm16_internal(int16_t* data, size_t length);
bool trim_silence_pcm16_internal(int16_t* data, size_t* length);
bool pad_silence_end_pcm16_internal(sample_t* sample, int milliseconds);

// Convert stereo to mono
void convert_to_mono_pcm16(sample_t *sample);

// Compatibility logic
bool adjust_to_akai_compatibility_internal(sample_t* sample, AkaiModel model);

#endif /* AKAIUTIL_AUDIOUTILS_H */
