//
//  commoninclude.h
//  AkaiSConvert
//

#ifndef COMMONINCLUDE_H
#define COMMONINCLUDE_H

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

// Type aliases
typedef long long OFF64_T;
typedef unsigned long long U_INT64;

// Sample structure
typedef struct sample_s {
    char name[64];
    uint32_t rate;
    uint8_t bits;
    uint8_t channels;
    uint8_t *data;
    uint32_t length;
} sample_t;

// Print and flush macros
#define PRINTF_OUT(...) printf(__VA_ARGS__)
#define PRINTF_ERR(...) fprintf(stderr, __VA_ARGS__)
#define FLUSH_ALL() fflush(stdout)

#endif /* COMMONINCLUDE_H */
