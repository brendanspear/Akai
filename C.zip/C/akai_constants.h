//
//  This file is part of AkaiSConvert.
//  Based on original work: akaiutil by Klaus Michael Indlekofer
//  Copyright (C) 2008-2025 Klaus Michael Indlekofer <m.indlekofer@gmx.de>
//  Released under GNU GPL v3.0 - https://www.gnu.org/licenses/gpl-3.0.html
//

//
//  akai_constants.h
//  AkaiSConvert
//
//  Created by Brendan Spear on 5/11/25.
//
#ifndef AKAI_CONSTANTS_H
#define AKAI_CONSTANTS_H

#define AKAI_S900    900
#define AKAI_S1000   1000
#define AKAI_S3000   3000

#endif // AKAI_CONSTANTS_H
