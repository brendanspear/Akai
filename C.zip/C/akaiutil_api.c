//
//  akaiutil_api.c
//  AkaiSConvert
//
//  Created by Brendan Spear.
//  Based on original work: akaiutil by Klaus Michael Indlekofer
//  Released under GNU GPL v3.0
//

#include "akaiutil_api.h"
#include "akaiutil_audioutils.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

// Create a sample_t structure from raw PCM data
sample_t* create_sample_from_pcm(const int16_t* data, size_t sample_count, uint32_t rate, uint8_t bits, uint8_t channels) {
    if (!data) return NULL;
    sample_t* sample = (sample_t*)malloc(sizeof(sample_t));
    if (!sample) return NULL;
    sample->data = malloc(sample_count * sizeof(int16_t));
    if (!sample->data) {
        free(sample);
        return NULL;
    }
    memcpy(sample->data, data, sample_count * sizeof(int16_t));
    sample->length = sample_count;
    sample->rate = rate;
    sample->bits = bits;
    sample->channels = channels;
    snprintf(sample->name, sizeof(sample->name), "Exported");
    return sample;
}

// Free memory used by sample_t
void free_sample(sample_t* sample) {
    if (sample) {
        if (sample->data) free(sample->data);
        free(sample);
    }
}

// Apply normalization
bool normalize_pcm16(sample_t* sample) {
    if (!sample || !sample->data || sample->length == 0) return false;
    return normalize_pcm16_internal(sample->data, sample->length);
}

// Trim silence
bool trim_silence_pcm16(sample_t* sample) {
    if (!sample || !sample->data || sample->length == 0) return false;
    return trim_silence_pcm16_internal(sample->data, &sample->length);
}

// Pad silence at end
bool pad_silence_end_pcm16(sample_t* sample, int milliseconds) {
    if (!sample || !sample->data || sample->length == 0) return false;
    return pad_silence_end_pcm16_internal(sample, milliseconds);
}

// Apply all requested processing options
bool process_samples_with_options(sample_t* sample, const AkaiExportOptions* options) {
    if (!sample || !options) return false;
    if (options->normalize) normalize_pcm16(sample);
    if (options->trim_silence) trim_silence_pcm16(sample);
    if (options->pad_silence) pad_silence_end_pcm16(sample, options->silence_ms);
    return true;
}

// Final adjustment for Akai compatibility
bool adjust_to_akai_compatibility(sample_t* sample, AkaiModel model) {
    if (!sample || !sample->data || sample->length == 0) return false;
    return adjust_to_akai_compatibility_internal(sample, model);
}
